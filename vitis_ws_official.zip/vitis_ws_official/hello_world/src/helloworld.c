/******************************************************************************
* Copyright (C) 2023 Advanced Micro Devices, Inc. All Rights Reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/

#include <stdint.h>
#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xil_io.h"
#include "xgpio.h"
#include "sleep.h"

// Including songs
#include "point_scored.h"
#include "paddle_hit.h"
#include "mary_lamb.h"

/************************** Constant Definitions *****************************/
#define GPIO_ONE  XPAR_XGPIO_0_BASEADDR 
#define LED_ON  0xAA
#define LED_OFF 0x55
#define LED_ALL_OFF 0x00

#define TCSR0_OFFSET   0x00  // Control/Status Register 0
#define TLR0_OFFSET    0x04  // Load Register 0 (Period)
#define TCR0_OFFSET    0x08  // Timer Counter Register 0

#define TCSR1_OFFSET   0x10  // Control/Status Register 1
#define TLR1_OFFSET    0x14  // Load Register 1 (Duty Cycle)
#define TCR1_OFFSET    0x18  // Timer Counter Register 1

#define PWM_ENABLE     0b01010000100
#define PWM_LOAD       0b100000

#define LED_CTL_BASE XPAR_APB_LED_CTL_0_BASEADDR
#define LED_REG_OFFSET 0x00  // likely register offset for LED[7:0]

#define TIMER_BASEADDR XPAR_AXI_TIMER_0_BASEADDR

#define MAX_COUNT 0xFFFFFFFF

#define AXI_CLK_HZ XPAR_XTMRCTR_0_CLOCK_FREQUENCY

/************************** Function Prototypes ******************************/

int SystemInit(void);
int predict(int start_y, int dir_y, int width, int height);
int mod(int a, int b);
void play_audio(const uint8_t* data, int len, int pwm_freq);

/************************** Variable Definitions *****************************/
XGpio Gpio1; /* The Instance of the GPIO Driver */


int main()
{
    init_platform();

    // Task 3
    print("SoC Design Class Final Project (Group 11)\n\r");
    print("Task 3: Pong Game with Audio Functions\n\r");

    sleep(1);

    int Status = XST_SUCCESS;

    Status = SystemInit();

    if(Status == XST_FAILURE)
    {
        print("System init failed\r\n");
        while(1);
    }

    const u8 GAME_START = 0b10000;
    const u8 GAME_RESTART = 0b00000;

    Status = Xil_SecureOut32(XPAR_MYIP_PONG2_0_BASEADDR + (4 * 0), GAME_RESTART);

    print("Starting Game\r\n");
    play_audio(mary_lamb_data, mary_lamb_length, 500000);
    sleep(1);

    Status = Xil_SecureOut32(XPAR_MYIP_PONG2_0_BASEADDR + (4 * 0), GAME_START);

    if(Status == XST_FAILURE)
    {
        print("Address pong Write failed\r\n");
        while(1);
    }

    int ball_predict = 0;
    uint8_t prev_p1_score = 0;
    uint8_t prev_p2_score = 0;
    int prev_ball_x = 0;
    int prev_x_direction = 1; 
    int x_direction = 1;

    while (1) {

        // read from gpio
        u32 paddle_data = XGpio_DiscreteRead(&Gpio1, 1);

        // write value to paddle register

        u32 reg2_val = Xil_In32(XPAR_MYIP_PONG2_0_BASEADDR + (4 * 2));

        int ball_x = reg2_val & 0x3F;
        int ball_y = (reg2_val >> 6) & 0x3F;
        int paddle_top = (reg2_val >> 12) & 0x3F;
        int paddle_bot = (reg2_val >> 18) & 0x3F;

        int paddle_mid = ((paddle_top + paddle_bot)/2);
        int dir_y = (reg2_val >> 25) & 0x01;


        if(ball_x == 0) {
            ball_predict = predict(ball_y, dir_y, 40,30);
        }
        if (paddle_mid > ball_predict) {
            Xil_Out32(XPAR_MYIP_PONG2_0_BASEADDR + (4 * 0), GAME_START | paddle_data | 0b1000);
        }
        else if (paddle_mid < ball_predict) {
            Xil_Out32(XPAR_MYIP_PONG2_0_BASEADDR + (4 * 0), GAME_START | paddle_data | 0b0100);
        }
        else {
            Xil_Out32(XPAR_MYIP_PONG2_0_BASEADDR + (4 * 0), GAME_START | paddle_data | 0b000);
        }

        // SCORE Verification: Read SLV_REG1
        u32 reg1 = Xil_In32(XPAR_MYIP_PONG2_0_BASEADDR + 4); // SLV_REG1
        uint8_t p1_score = reg1 & 0x0F;
        uint8_t p2_score = (reg1 >> 4) & 0x0F;
        // Debug prints
        //xil_printf("p1_score = %d\r\n", p1_score);
        //xil_printf("p2_score = %d\r\n", p2_score);
        //xil_printf("prev_p1_score = %d\r\n", prev_p1_score);
        //xil_printf("prev_p2_score = %d\r\n", prev_p2_score);

        // Point sound effect
        if (p1_score != prev_p1_score || p2_score != prev_p2_score){
            if (p1_score == 9 || p2_score == 9){
                ball_predict = 0;
                prev_p1_score = 0;          // Reset previous P1 score
                prev_p2_score = 0;          // Reset previous P2 score
                prev_ball_x = 0;            // Reset previous ball location
                prev_x_direction = 1;       // Reset previous ball direction
                x_direction = 1;            // Reset current ball direction
                play_audio(mary_lamb_data, mary_lamb_length, 500000);
                //xil_printf("marry had a little lamb sound\r\n");
                Status = Xil_SecureOut32(XPAR_MYIP_PONG2_0_BASEADDR + (4 * 0), GAME_RESTART);
                sleep(1);
                Status = Xil_SecureOut32(XPAR_MYIP_PONG2_0_BASEADDR + (4 * 0), GAME_START);
            }
            else {
                prev_p1_score = p1_score;
                prev_p2_score = p2_score;
                prev_ball_x = 0;            // Reset previous ball location
                prev_x_direction = 1;       // Reset previous ball direction
                x_direction = 1;            // Reset current ball direction
                play_audio(point_scored_data, point_scored_length, 500000);
                //xil_printf("score sound\r\n");
            }
        }

        // Paddle sound effect
        x_direction = ball_x - prev_ball_x;
        if (x_direction * prev_x_direction < 0) {
            prev_x_direction = x_direction; // update the ball direction
            play_audio(paddle_hit_data, paddle_hit_length, 500000);
            //xil_printf("paddle sound\r\n");
        }
        prev_ball_x = ball_x;

    }

    print("Exited Error\r\n");
    cleanup_platform();
    return 0;
}


//////////////////////f(x)///////////
int SystemInit(void)
{
    int Status = XST_SUCCESS;

	Status = XGpio_Initialize(&Gpio1, GPIO_ONE);
	if (Status != XST_SUCCESS) {
		xil_printf("Gpio Initialization Failed\r\n");
		return XST_FAILURE;
	}
    
    Status = XGpio_SelfTest(&Gpio1);
	if (Status != XST_SUCCESS) {
		xil_printf("Gpio self-test Failed\r\n");
		return XST_FAILURE;
	}

    return Status;
}

int mod(int a, int b) {
    int r = a % b;
    return r < 0 ? r + b : r;
}

int predict(int start_y, int dir_y, int width, int height) {
    int vertical_movement;
    
    if (dir_y == 1) { 
        vertical_movement = width;
    } else {
        vertical_movement = -width;
    }
    
    int q = mod(vertical_movement, 2 * height);
    int final_pos = start_y + q;

    if (final_pos >= height) {
        final_pos = height - (final_pos - height);
    } else if (final_pos < 0) {
        final_pos = -final_pos;
    }
    
    return final_pos;
}

void play_audio(const uint8_t* data, int len, int pwm_freq) {
    const u32 SAMPLE_RATE_HZ = 8000; // Desired audio sample rate (8 kHz)
    u32 period_cycles = (AXI_CLK_HZ / pwm_freq) - 2;

    for (int i = 0; i < len; i++) {
        
        u32 duty_cycles = (period_cycles * data[i]) / 255; // duty cycle based on 8-bit audio tables

        // Disable timers
        Xil_Out32(TIMER_BASEADDR + TCSR0_OFFSET, 0x00000000);
        Xil_Out32(TIMER_BASEADDR + TCSR1_OFFSET, 0x00000000);

        // Load period and duty cycle
        Xil_Out32(TIMER_BASEADDR + TLR0_OFFSET, period_cycles);
        Xil_Out32(TIMER_BASEADDR + TLR1_OFFSET, duty_cycles);

        // Set LOAD bits to transfer TLR values to counters
        u32 config = (1 << 5) | (1 << 4) | (1 << 9) | (1 << 2) | (1 << 1); // LOAD, ARHT, PWMA0, GENT, UDT
        Xil_Out32(TIMER_BASEADDR + TCSR0_OFFSET, config);
        Xil_Out32(TIMER_BASEADDR + TCSR1_OFFSET, config);

        // Clear LOAD bits and enable timers
        config &= ~(1 << 5); // Clear LOAD bit
        config |= (1 << 7);  // Set ENT bit to enable timers
        Xil_Out32(TIMER_BASEADDR + TCSR0_OFFSET, config);
        Xil_Out32(TIMER_BASEADDR + TCSR1_OFFSET, config);

        // Wait for one sample period ( 1s / fs)
        usleep(1000000 / SAMPLE_RATE_HZ);
    }

    // Disable timers after playback
    Xil_Out32(TIMER_BASEADDR + TCSR0_OFFSET, 0x00000000);
    Xil_Out32(TIMER_BASEADDR + TCSR1_OFFSET, 0x00000000);
}