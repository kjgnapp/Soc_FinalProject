#ifndef XMEM_CONFIG_H_
#define XMEM_CONFIG_H_

#define XPAR_LMB_BRAM_0_BASEADDRESS 0x0
#define XPAR_LMB_BRAM_0_HIGHADDRESS 0x3ffff

#endif